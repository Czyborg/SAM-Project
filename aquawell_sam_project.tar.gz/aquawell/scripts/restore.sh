#!/usr/bin/env bash
# AI-assisted: Google Gemini (script structure, --help flags, and tar/pg_restore logic)
set -e

if [[ "$1" == "--help" || "$1" == "-h" ]]; then
  echo "Usage: ./restore.sh [path/to/backup.tar.gz] [--help]"
  echo "Extracts the newest (or specified) .tar.gz archive from backups/, rebuilds 'aquawell',"
  echo "restores schema and test data, re-applies grants, and verifies live tables."
  exit 0
fi

DB_NAME="aquawell"
APP_USER="aquawell_app"
APP_PASS="${DB_PASS:-12345}"
BACKUP_DIR="$HOME/aquawell/backups"
EXTRACT_DIR="/tmp/aquawell_restore_$$"

if [[ -n "$1" ]]; then
  TAR_ARCHIVE="$1"
else
  TAR_ARCHIVE=$(ls -t "$BACKUP_DIR"/aquawell_backup_*.tar.gz 2>/dev/null | head -n 1)
fi

if [[ -z "$TAR_ARCHIVE" || ! -f "$TAR_ARCHIVE" ]]; then
  echo "Error: No .tar.gz backup archive found in $BACKUP_DIR"
  exit 1
fi

echo "=== [1/4] Extracting TAR Archive ==="
mkdir -p "$EXTRACT_DIR"
tar -xzvf "$TAR_ARCHIVE" -C "$EXTRACT_DIR"
DUMP_FILE=$(find "$EXTRACT_DIR" -name "*.dump" | head -n 1)

echo "=== [2/4] Rebuilding Database ($DB_NAME) ==="
sudo systemctl is-active --quiet postgresql || sudo systemctl start postgresql
sudo -u postgres psql -c "DROP DATABASE IF EXISTS $DB_NAME;" > /dev/null
sudo -u postgres psql -c "CREATE DATABASE $DB_NAME;" > /dev/null

echo "=== [3/4] Restoring Schema & Data from Extracted Dump ==="
sudo -u postgres pg_restore -d "$DB_NAME" --no-owner < "$DUMP_FILE"
rm -rf "$EXTRACT_DIR"

sudo -u postgres psql -d "$DB_NAME" -c "
  GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $APP_USER;
  GRANT USAGE ON SCHEMA public, auth TO $APP_USER;
  GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public, auth TO $APP_USER;
  GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO $APP_USER;
" > /dev/null

echo "=== [4/4] Verifying Restored Server & Live Tables ==="
PGPASSWORD="$APP_PASS" psql -h localhost -p 5432 -U "$APP_USER" -d "$DB_NAME" \
  -c "SELECT current_database(), current_user, inet_server_addr(), inet_server_port();" \
  -c "\dt public.*" \
  -c "SELECT order_reference, customer_name, total, status FROM public.orders;" \
  -c "SELECT * FROM public.inventory;"
echo "Restore from TAR complete!"
