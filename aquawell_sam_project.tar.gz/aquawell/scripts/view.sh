#!/usr/bin/env bash
# AI-assisted: Google Gemini (script structure, --help flags, and tar/pg_restore logic)

if [[ "$1" == "--help" || "$1" == "-h" ]]; then
  echo "Usage: ./view.sh [--help]"
  echo "Connects as 'aquawell_app' to verify server port, public tables, orders, and inventory."
  exit 0
fi

APP_PASS="${DB_PASS:-12345}"
PGPASSWORD="$APP_PASS" psql -h localhost -p 5432 -U aquawell_app -d aquawell \
  -c "SELECT current_database(), current_user, inet_server_addr(), inet_server_port();" \
  -c "\dt public.*" \
  -c "SELECT order_reference, customer_name, total, status FROM public.orders;" \
  -c "SELECT * FROM public.inventory;"
