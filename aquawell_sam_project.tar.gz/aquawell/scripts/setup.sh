#!/usr/bin/env bash
# AI-assisted: Google Gemini (script structure, --help flags, and tar/pg_restore logic)
set -e

if [[ "$1" == "--help" || "$1" == "-h" ]]; then
  echo "Usage: ./setup.sh [--help]"
  echo "Provisions the 'aquawell' PostgreSQL database, creates the 'aquawell_app' role,"
  echo "imports schema and test seed data, applies grants, and displays live tables."
  exit 0
fi

DB_NAME="aquawell"
APP_USER="aquawell_app"
APP_PASS="${DB_PASS:-12345}"
BASE_DIR="$HOME/aquawell"

echo "=== [1/4] Starting PostgreSQL & Creating Database ==="
sudo systemctl is-active --quiet postgresql || sudo systemctl start postgresql
sudo -u postgres psql -c "DROP DATABASE IF EXISTS $DB_NAME;"
sudo -u postgres psql -c "CREATE DATABASE $DB_NAME;"

echo "=== [2/4] Creating Application User ($APP_USER) ==="
sudo -u postgres psql -c "DO \$\$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '$APP_USER') THEN
    CREATE ROLE $APP_USER WITH LOGIN PASSWORD '$APP_PASS';
  ELSE
    ALTER ROLE $APP_USER WITH PASSWORD '$APP_PASS';
  END IF;
END \$\$;"

echo "=== [3/4] Creating Auth Schema & Importing Schema + Sample Data ==="
sudo -u postgres psql -d "$DB_NAME" -v ON_ERROR_STOP=1 -c "
  CREATE SCHEMA IF NOT EXISTS auth;
  CREATE TABLE IF NOT EXISTS auth.users (id uuid PRIMARY KEY);
" > /dev/null
sudo -u postgres psql -d "$DB_NAME" -v ON_ERROR_STOP=1 -f "$BASE_DIR/aquawell_schema.sql" > /dev/null
sudo -u postgres psql -d "$DB_NAME" -v ON_ERROR_STOP=1 -f "$BASE_DIR/seed_data.sql" > /dev/null

echo "=== [4/4] Setting Permissions & Displaying Live Tables ==="
sudo -u postgres psql -d "$DB_NAME" -c "
  GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $APP_USER;
  GRANT USAGE ON SCHEMA public, auth TO $APP_USER;
  GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public, auth TO $APP_USER;
  GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO $APP_USER;
" > /dev/null

PGPASSWORD="$APP_PASS" psql -h localhost -p 5432 -U "$APP_USER" -d "$DB_NAME" \
  -c "SELECT current_database(), current_user, inet_server_addr(), inet_server_port();" \
  -c "\dt public.*" \
  -c "SELECT order_reference, customer_name, total, status FROM public.orders;" \
  -c "SELECT * FROM public.inventory;"
echo "Setup complete!"
