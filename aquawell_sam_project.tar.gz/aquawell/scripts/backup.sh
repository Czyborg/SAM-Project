#!/usr/bin/env bash
# AI-assisted: Google Gemini (script structure, --help flags, and tar/pg_restore logic)
set -e

if [[ "$1" == "--help" || "$1" == "-h" ]]; then
  echo "Usage: ./backup.sh [--help]"
  echo "Creates a PostgreSQL custom dump of 'aquawell' and compresses it into backups/*.tar.gz."
  exit 0
fi

DB_NAME="aquawell"
BACKUP_DIR="$HOME/aquawell/backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
DUMP_FILE="aquawell_${TIMESTAMP}.dump"
TAR_ARCHIVE="$BACKUP_DIR/aquawell_backup_${TIMESTAMP}.tar.gz"

mkdir -p "$BACKUP_DIR"

echo "=== [1/2] Creating PostgreSQL Database Dump ==="
sudo systemctl is-active --quiet postgresql || sudo systemctl start postgresql
sudo -u postgres pg_dump -F c "$DB_NAME" > "/tmp/$DUMP_FILE"

echo "=== [2/2] Compressing Backup into TAR Archive ==="
tar -czf "$TAR_ARCHIVE" -C /tmp "$DUMP_FILE"
rm -f "/tmp/$DUMP_FILE"

ls -lh "$TAR_ARCHIVE"
echo "Backup complete!"
