-- 1. Insert simulated Auth Users
INSERT INTO auth.users (id) VALUES
  ('11111111-1111-1111-1111-111111111111'),
  ('22222222-2222-2222-2222-222222222222'),
  ('33333333-3333-3333-3333-333333333333');

-- 2. Insert User Profiles (Admin, Rider, Customer)
INSERT INTO public.profiles (id, full_name, email, phone, address, barangay, role) VALUES
  ('11111111-1111-1111-1111-111111111111', 'Erin Admin', 'admin@aquawell.local', '09171000001', 'AquaWell Main Station', 'Poblacion', 'admin'),
  ('22222222-2222-2222-2222-222222222222', 'Marco Rider', 'rider@aquawell.local', '09171000002', 'Block 4 Lot 2', 'San Jose', 'delivery'),
  ('33333333-3333-3333-3333-333333333333', 'Maria Santos', 'maria@example.com', '09171000003', '123 Mabini St.', 'Real', 'customer');

-- 3. Insert Inventory Items
INSERT INTO public.inventory (name, category, price, stock, min_stock) VALUES
  ('Purified Water Refill (5 Gal)', 'Refill', 35.00, 150, 20),
  ('Slim Gallon Container with Faucet', 'Slim Gallon', 180.00, 40, 10);

-- 4. Insert a Sample Order & Order Item
INSERT INTO public.orders (order_reference, customer_id, type, total, status, payment_status, address, rider_id, customer_name) VALUES
  ('ORD-2026-0001', '33333333-3333-3333-3333-333333333333', 'Delivery', 105.00, 'DELIVERED', 'PAID', '123 Mabini St., Real', '22222222-2222-2222-2222-222222222222', 'Maria Santos');

INSERT INTO public.order_items (order_id, inventory_id, quantity, unit_price) VALUES
  (1, 1, 3, 35.00);






