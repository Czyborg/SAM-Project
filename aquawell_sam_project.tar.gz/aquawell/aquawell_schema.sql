-- AquaWell Executable Schema (PostgreSQL 18)

-- 1. Core Independent / Auth-Linked Parent Tables
CREATE TABLE public.profiles (
  id uuid NOT NULL,
  full_name text NOT NULL DEFAULT ''::text,
  email text NOT NULL DEFAULT ''::text,
  phone text,
  address text,
  barangay text,
  landmark text,
  role text NOT NULL DEFAULT 'customer'::text CHECK (role = ANY (ARRAY['admin'::text, 'staff'::text, 'delivery'::text, 'customer'::text])),
  delivery_availability text NOT NULL DEFAULT 'AVAILABLE'::text CHECK (delivery_availability = ANY (ARRAY['AVAILABLE'::text, 'UNAVAILABLE'::text])),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  pin_lat double precision CHECK (pin_lat >= '-90'::integer::double precision AND pin_lat <= 90::double precision),
  pin_lng double precision CHECK (pin_lng >= '-180'::integer::double precision AND pin_lng <= 180::double precision),
  CONSTRAINT profiles_pkey PRIMARY KEY (id),
  CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id)
);

CREATE TABLE public.inventory (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  name text NOT NULL CHECK (length(btrim(name)) > 0),
  category text NOT NULL CHECK (category = ANY (ARRAY['Refill'::text, 'Hardware'::text, 'Round Gallon'::text, 'Slim Gallon'::text, 'Caps'::text, 'Seals'::text])),
  price numeric NOT NULL CHECK (price >= 0::numeric),
  stock integer NOT NULL DEFAULT 0 CHECK (stock >= 0),
  min_stock integer NOT NULL DEFAULT 10 CHECK (min_stock >= 0),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  image_url text,
  CONSTRAINT inventory_pkey PRIMARY KEY (id)
);

CREATE TABLE public.companies (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  name text NOT NULL CHECK (length(btrim(name)) > 0),
  focal_person_name text NOT NULL CHECK (length(btrim(focal_person_name)) > 0),
  contact_information text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT companies_pkey PRIMARY KEY (id)
);

-- 2. Second-Level Tables (Depend on profiles, inventory, or companies)
CREATE TABLE public.orders (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  order_reference text NOT NULL UNIQUE,
  customer_id uuid,
  type text NOT NULL CHECK (type = ANY (ARRAY['Delivery'::text, 'Pickup'::text])),
  total numeric NOT NULL DEFAULT 0 CHECK (total >= 0::numeric),
  status text NOT NULL DEFAULT 'PENDING'::text CHECK (status = ANY (ARRAY['PENDING'::text, 'CONFIRMED'::text, 'OUT FOR-DELIVERY'::text, 'DELIVERED'::text, 'READY FOR PICKUP'::text, 'PICKED UP'::text, 'CANCELLED'::text, 'UNABLE TO FULFILL'::text])),
  payment_status text NOT NULL DEFAULT 'PENDING'::text CHECK (payment_status = ANY (ARRAY['PENDING'::text, 'UNPAID'::text, 'PAID'::text, 'CANCELLED'::text, 'REFUNDED'::text])),
  address text,
  rider_id uuid,
  customer_received_at timestamp with time zone,
  stock_deducted boolean NOT NULL DEFAULT false,
  archived boolean NOT NULL DEFAULT false,
  cancellation_reason text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  customer_name text,
  walk_in_customer_name text,
  completed_at timestamp with time zone,
  dest_lat double precision,
  dest_lng double precision,
  out_for_delivery_at timestamp with time zone,
  CONSTRAINT orders_pkey PRIMARY KEY (id),
  CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.profiles(id),
  CONSTRAINT orders_rider_id_fkey FOREIGN KEY (rider_id) REFERENCES public.profiles(id)
);

CREATE TABLE public.audit_logs (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  user_id uuid,
  user_name text NOT NULL DEFAULT 'System'::text,
  action text NOT NULL,
  log_type text NOT NULL DEFAULT 'SYSTEM'::text,
  timestamp timestamp with time zone NOT NULL DEFAULT now(),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT audit_logs_pkey PRIMARY KEY (id),
  CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id)
);

CREATE TABLE public.customer_company_affiliations (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  customer_id uuid NOT NULL,
  company_id bigint NOT NULL,
  affiliation_type text NOT NULL DEFAULT 'Member'::text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT customer_company_affiliations_pkey PRIMARY KEY (id),
  CONSTRAINT customer_company_affiliations_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.profiles(id),
  CONSTRAINT customer_company_affiliations_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id)
);

CREATE TABLE public.company_billing_records (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  company_id bigint NOT NULL,
  billing_period date NOT NULL,
  amount_due numeric NOT NULL CHECK (amount_due >= 0::numeric),
  amount_paid numeric NOT NULL DEFAULT 0 CHECK (amount_paid >= 0::numeric),
  status text NOT NULL DEFAULT 'UNPAID'::text CHECK (status = ANY (ARRAY['UNPAID'::text, 'PARTIALLY_PAID'::text, 'PAID'::text, 'VOID'::text])),
  payment_reference text,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT company_billing_records_pkey PRIMARY KEY (id),
  CONSTRAINT company_billing_records_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id)
);

CREATE TABLE public.role_permissions (
  role text NOT NULL CHECK (role = ANY (ARRAY['staff'::text, 'delivery'::text])),
  permission text NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_by uuid,
  CONSTRAINT role_permissions_pkey PRIMARY KEY (role, permission),
  CONSTRAINT role_permissions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.profiles(id)
);

CREATE TABLE public.inventory_movements (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  inventory_id bigint NOT NULL,
  item_name text NOT NULL,
  delta integer NOT NULL,
  stock_before integer NOT NULL,
  stock_after integer NOT NULL CHECK (stock_after >= 0),
  reason text NOT NULL DEFAULT 'Stock change'::text,
  actor_id uuid,
  actor_name text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT inventory_movements_pkey PRIMARY KEY (id),
  CONSTRAINT inventory_movements_inventory_id_fkey FOREIGN KEY (inventory_id) REFERENCES public.inventory(id),
  CONSTRAINT inventory_movements_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.profiles(id)
);

CREATE TABLE public.rider_locations (
  rider_id uuid NOT NULL,
  lat double precision NOT NULL CHECK (lat >= '-90'::integer::double precision AND lat <= 90::double precision),
  lng double precision NOT NULL CHECK (lng >= '-180'::integer::double precision AND lng <= 180::double precision),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT rider_locations_pkey PRIMARY KEY (rider_id),
  CONSTRAINT rider_locations_rider_id_fkey FOREIGN KEY (rider_id) REFERENCES public.profiles(id)
);

CREATE TABLE public.station_settings (
  id smallint NOT NULL DEFAULT 1 CHECK (id = 1),
  lat double precision NOT NULL CHECK (lat >= '-90'::integer::double precision AND lat <= 90::double precision),
  lng double precision NOT NULL CHECK (lng >= '-180'::integer::double precision AND lng <= 180::double precision),
  label text,
  updated_by uuid,
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT station_settings_pkey PRIMARY KEY (id),
  CONSTRAINT station_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.profiles(id)
);

-- 3. Third-Level Tables (Depend on orders)
CREATE TABLE public.order_items (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  order_id bigint NOT NULL,
  inventory_id bigint NOT NULL,
  quantity integer NOT NULL CHECK (quantity > 0),
  unit_price numeric NOT NULL CHECK (unit_price >= 0::numeric),
  subtotal numeric GENERATED ALWAYS AS ((quantity)::numeric * unit_price) STORED,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT order_items_pkey PRIMARY KEY (id),
  CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id),
  CONSTRAINT order_items_inventory_id_fkey FOREIGN KEY (inventory_id) REFERENCES public.inventory(id)
);

CREATE TABLE public.payments (
  payment_id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  order_id bigint NOT NULL,
  amount numeric NOT NULL CHECK (amount >= 0::numeric),
  payment_method text NOT NULL CHECK (payment_method = ANY (ARRAY['Cash'::text, 'Cash on Delivery'::text, 'GCash'::text, 'Bank Transfer'::text])),
  payment_status text NOT NULL DEFAULT 'PENDING'::text CHECK (payment_status = ANY (ARRAY['PENDING'::text, 'UNPAID'::text, 'PAID'::text, 'CANCELLED'::text, 'REFUNDED'::text])),
  receipt_url text,
  paid_at timestamp with time zone,
  verified_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT payments_pkey PRIMARY KEY (payment_id),
  CONSTRAINT payments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id),
  CONSTRAINT payments_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.profiles(id)
);

CREATE TABLE public.sales (
  transaction_id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  order_id bigint NOT NULL UNIQUE,
  customer_name text NOT NULL,
  item_name text NOT NULL,
  quantity integer NOT NULL CHECK (quantity > 0),
  total_amount numeric NOT NULL CHECK (total_amount >= 0::numeric),
  payment_method text NOT NULL,
  date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT sales_pkey PRIMARY KEY (transaction_id),
  CONSTRAINT sales_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id)
);

CREATE TABLE public.notifications (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  user_id uuid NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  order_id bigint,
  unread boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT notifications_pkey PRIMARY KEY (id),
  CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id),
  CONSTRAINT notifications_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id)
);

CREATE TABLE public.delivery_events (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  order_id bigint NOT NULL,
  actor_id uuid,
  event_type text NOT NULL CHECK (event_type = ANY (ARRAY['ASSIGNED'::text, 'REJECTED'::text, 'OUT_FOR_DELIVERY'::text, 'RIDER_MARKED_DELIVERED'::text, 'CUSTOMER_CONFIRMED_RECEIPT'::text, 'FAILED_ATTEMPT'::text, 'REASSIGNED'::text, 'NOTE'::text])),
  details text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT delivery_events_pkey PRIMARY KEY (id),
  CONSTRAINT delivery_events_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id),
  CONSTRAINT delivery_events_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.profiles(id)
);
